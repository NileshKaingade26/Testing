﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using Framework.Settings;
using System;
using System.Configuration;

namespace specflow
{
    public class DriverFactory
    {
        private IWebDriver driver;

        public IWebDriver getDriver()
        {
            if (driver == null)
            {
                setDriver();
            }
            return driver;
        }
        private void setDriver()
        {
            string browser = ConfigurationManager.AppSettings.Get(AppConfigKeys.Browser);

            if (browser.Equals("Chrome"))
            {
                driver = new ChromeDriver();
            }
            else if (browser.Equals("Edge"))
            {
                driver = new EdgeDriver();
            }

            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            driver.Manage().Window.Maximize();
        }
    }
}
